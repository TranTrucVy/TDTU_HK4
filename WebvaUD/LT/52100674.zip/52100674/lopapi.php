<?php
    class LopHocController {
        private $db;
        public function __construct()
        {
            $this->db = new mysqli('localhost', 'root', '', 'dbstudent');
            if ($this->db->connect_errno) 
                die ("Lỗi kết nối: " . $this->db->connect_error);
        }
        public function __destruct()
        {
            $this->db->close();
        }
        public function get_list($kw = "") {
            $res = $this->db->query("select * from lop");
            $rows = [];
            while($row = mysqli_fetch_assoc($res)) {
                $rows[] = $row;
            }
            return $rows;
        }
        public function get_one($ms) {
            //..
            $res=$this->db->query("select * from lop where malop='$ms'");
            $row = mysqli_fetch_assoc($res);
            return $row;
        }
    }
    header('Content-Type: application/json; charset=utf-8');
    $sv = new LopHocController;
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        $data = array('success' => true, "data"=> $sv->get_list());
        echo json_encode($data);
    }
    else if ($_SERVER["REQUEST_METHOD"] == "POST") {
        echo '{"success":false, "message":"Method Chưa hỗ trợ"}';
    }
    else if($_SERVER["REQUEST_METHOD"] == "PUT"){
        $data = json_decode(file_get_contents('php://input'), true);
        $ms = $data['ms'];
        $ten = $data['ten'];
        $ns = $data['ns'];
        $malop = $data['malop'];
        $res = $sv->db->query("insert into sinhvien values('$ms', '$ten', '$ns', '$malop')");
        if ($res) {
            $data = array('success' => true, "message"=> "Thêm thành công");
            echo json_encode($data);
        }
        else {
            $data = array('success' => false, "message"=> "Thêm thất bại");
            echo json_encode($data);
        }
    }
?>