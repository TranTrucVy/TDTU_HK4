<?php
    class SinhVienController {
        private $db;
        public function __construct()
        {
            $this->db = new mysqli('localhost', 'root', '', 'dbstudent');
            if ($this->db->connect_errno) 
                die ("Lỗi kết nối: " . $this->db->connect_error);
        }
        public function __destruct()
        {
            $this->db->close();
        }
        public function get_list($kw = "") {
            $res = $this->db->query("select s.*, l.tenlop from sinhvien s inner join lop l on s.malop=l.ms");
            $rows = [];
            while($row = mysqli_fetch_assoc($res)) {
                $rows[] = $row;
            }
            return $rows;
        }
        public function get_one($ms) {
            //..
            $res=$this->db->query("select * from sinhvien where ms='$ms'");
            $row = mysqli_fetch_assoc($res);
            return $row;
        }

        public function add($ms, $ten, $ns, $malop) {
            $res = $this->db->query("insert into sinhvien values('$ms', '$ten', '$ns', '$malop')");
            if ($res) {
                $data = array('success' => true, "message"=> "Thêm thành công");
                echo json_encode($data);
            }
            else {
                $data = array('success' => false, "message"=> "Thêm thất bại");
                echo json_encode($data);
            }
        }

        public function delete($ms){
            $res = $this->db->query("delete from sinhvien where ms='$ms'");
            if ($res) {
                $data = array('success' => true, "message"=> "Xóa thành công");
                echo json_encode($data);
            }
            else {
                $data = array('success' => false, "message"=> "Xóa thất bại");
                echo json_encode($data);
            }
        }

        public function update($ms, $ten, $ns, $malop){
            $res=$this->db->query("update sinhvien set ten='$ten', ngaysinh='$ns', malop='$malop' where ms='$ms'");
            if ($res) {
                $data = array('success' => true, "message"=> "Cập nhật thành công");
                echo json_encode($data);
            }
            else {
                $data = array('success' => false, "message"=> "Cập nhật thất bại");
                echo json_encode($data);
            }
        }
    }
    header('Content-Type: application/json; charset=utf-8');
    $sv = new SinhVienController;
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        //...
        //trả về json dssv
        $data = array('success' => true, "data"=> $sv->get_list());
        echo json_encode($data);
    }
    else if ($_SERVER["REQUEST_METHOD"] == "POST") {
        //thêm sv
        $data = json_decode(file_get_contents('php://input'), true);
        $ms = $data['ms'];
        $ten = $data['ten'];
        $ns = $data['ns'];
        $malop = $data['malop'];
        $sv->add($ms, $ten, $ns, $malop);
    }
    //PUT, DELETE
    else if($_SERVER['REQUEST_METHOD'] == 'DELETE'){
        $data = json_decode(file_get_contents('php://input'), true);
        $ms = $data['ms'];
        $sv->delete($ms);
    }
    else if($_SERVER['REQUEST_METHOD'] == 'PUT'){
        $data = json_decode(file_get_contents('php://input'), true);
        $ms = $data['ms'];
        $ten = $data['ten'];
        $ns = $data['ns'];
        $malop = $data['malop'];
        $sv->update($ms, $ten, $ns, $malop);
    }
    else {
        echo '{"success":false, "message":"Method không hỗ trợ"}';
    }
?>